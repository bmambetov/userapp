package Model;

/**
 * Created by Rajesh Dabhi on 27/6/2017.
 */

public class Support_info_model {

    String id;
    String pg_title;
    String pg_slug;
    String pg_descri;
    String pg_status;
    String pg_foot;
    String crated_date;

    public String getId(){
        return id;
    }

    public String getPg_title(){
        return pg_title;
    }

    public String getPg_slug(){
        return pg_slug;
    }

    public String getPg_descri(){
        return pg_descri;
    }

    public String getPg_status(){
        return pg_status;
    }

    public String getPg_foot(){
        return pg_foot;
    }

    public String getCrated_date(){
        return crated_date;
    }

}
