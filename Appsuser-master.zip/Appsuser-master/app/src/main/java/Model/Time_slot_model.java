package Model;

/**
 * Created by Rajesh Dabhi on 27/6/2017.
 */

public class Time_slot_model {

    String date;
    String from_time;
    String to_time;
    String slot;

    public String getDate(){
        return date;
    }

    public String getFrom_time(){
        return from_time;
    }

    public String getTo_time(){
        return to_time;
    }

    public String getSlot(){
        return slot;
    }

}
